$(function(){

	alert ("funcionando");

	}