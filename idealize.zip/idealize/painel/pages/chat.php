<div class="box-content">
	<h2><i class="fa fa-comments-o" aria-hidden="true"></i> Chat Online</h2>

	<div class="box-Chat-Online">

		<?php
		for ($i=0; $i < 30; $i++) { 
		
		?>
	<div class="mensagem Chat">

		<span>Idealizeti:</span>
		<p> Ola Pessoa estou novamente de regresso</p>
		</div><!-- class="mensagem Chat-->
<?php } ?>

   </div><!--box-Chat-Online-->
   <form>
   	
   	<textarea></textarea>
   	<input type="submit" name="acao" value="Enviar">
   </form>

</div>