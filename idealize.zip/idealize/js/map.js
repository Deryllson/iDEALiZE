$(function(){

	
	//initialize();
	//addMarker(-27.609959,-48.576585,'',"Minha casa",undefined,false);

})