-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 08-Ago-2019 às 16:28
-- Versão do servidor: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idealize`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_admin.online`
--

CREATE TABLE `tb_admin.online` (
  `id` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `ultima_acao` datetime NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_admin.usuarios`
--

CREATE TABLE `tb_admin.usuarios` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cargo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_admin.usuarios`
--

INSERT INTO `tb_admin.usuarios` (`id`, `user`, `password`, `img`, `nome`, `cargo`) VALUES
(1, 'admin', 'admin', '5d2b25027e53b.jpg', 'Andre Cacueji Jeremias', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_admin.visitas`
--

CREATE TABLE `tb_admin.visitas` (
  `id` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `dia` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_admin.visitas`
--

INSERT INTO `tb_admin.visitas` (`id`, `ip`, `dia`) VALUES
(1, '::1', '2017-06-12'),
(2, '192.168.0.2', '2017-06-11'),
(3, '::1', '2017-06-13'),
(4, '::1', '2017-06-13'),
(5, '::1', '2017-06-13'),
(6, '::1', '2017-06-13'),
(7, '::1', '2017-06-14'),
(8, '::1', '2017-06-14'),
(9, '::1', '2017-06-16'),
(10, '::1', '2017-06-20'),
(11, '::1', '2017-06-20'),
(12, '::1', '2017-06-20'),
(13, '::1', '2017-06-20'),
(14, '::1', '2017-06-26'),
(15, '::1', '2017-06-27'),
(16, '::1', '2017-07-03'),
(17, '::1', '2019-06-22'),
(18, '::1', '2019-06-22'),
(19, '::1', '2019-06-22'),
(20, '::1', '2019-07-02'),
(21, '::1', '2019-07-07'),
(22, '::1', '2019-07-07'),
(23, '::1', '2019-07-07'),
(24, '192.168.1.2', '2019-07-08'),
(25, '::1', '2019-07-14'),
(26, '::1', '2019-07-14'),
(27, '::1', '2019-07-14'),
(28, '::1', '2019-07-14'),
(29, '192.168.1.3', '2019-07-14'),
(30, '192.168.1.3', '2019-07-16'),
(31, '192.168.1.3', '2019-07-16'),
(32, '::1', '2019-07-27'),
(33, '::1', '2019-07-27'),
(34, '192.168.1.3', '2019-07-31'),
(35, '::1', '2019-08-06'),
(36, '::1', '2019-08-08');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_site.categorias`
--

CREATE TABLE `tb_site.categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_site.categorias`
--

INSERT INTO `tb_site.categorias` (`id`, `nome`, `slug`, `order_id`) VALUES
(3, 'Geral', 'geral', 3),
(4, 'Cotidiano', 'cotidiano', 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_site.config`
--

CREATE TABLE `tb_site.config` (
  `titulo` varchar(255) NOT NULL,
  `nome_autor` varchar(255) NOT NULL,
  `descricao` text NOT NULL,
  `icone1` varchar(255) NOT NULL,
  `descricao1` text NOT NULL,
  `icone2` varchar(255) NOT NULL,
  `descricao2` text NOT NULL,
  `icone3` varchar(255) NOT NULL,
  `descricao3` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_site.config`
--

INSERT INTO `tb_site.config` (`titulo`, `nome_autor`, `descricao`, `icone1`, `descricao1`, `icone2`, `descricao2`, `icone3`, `descricao3`) VALUES
('UJES - Moxico', 'André Cacueji Jeremias', 'O profissional técnico em informática pode executar variadas tarefas, como por exemplo:\r\n\r\n•	Suporte Técnico;\r\n•	Desenvolvimento de softwares;\r\n•	Webdesign – criação de sites;\r\n•	Configuração de Redes de computadores;\r\n•	Projetos em computação gráfica;\r\n•	Organização de banco de dados.\r\n\r\nPara seguir carreira de técnico de informática o interessado deve possuir, no mínimo, o Ensino Médio completo. Depois da formação básica como técnico em informática, é de grande conveniência a especialização em cursos de computação, informática e cursos de eletrônica. A maioria dos materiais utilizados na área é importada, então é imprescindível a noção de inglês para o entendimento destes manuais. \r\n\r\nCom a informação e as tecnologias em pleno desenvolvimento, são muitas as possibilidades de mercado para o profissional da área. As possibilidades de atuação dos técnicos de informática estão em instituições públicas, privadas e do terceiro setor que exigem sistemas de computadores, especialmente abrangendo programação de computadores. Em um mundo cada vez mais globalizado, a função deste profissional está nas estratégias para este nicho que se encontra em grande expansão, onde o mesmo deve descobrir aplicabilidades para as novas tecnologias da informação aos processos de negócios. Poder criar serviços e produtos novos para conquistar um diferencial em sua empresa, além de mostrar eficiência à administração, função esta, tradicional na área do emprego à informática. \r\n\r\nO profissional deve sempre estar se atualizando. Atuando de forma responsável e participativa no crescimento de atividades tecnológicas ligadas a área de informática. Ser criativo, se adaptar bem as mudanças e apresentar facilidade são requisitos muito importantes para quem deseja seguir a carreira.\r\n\r\nOs principais mercados de trabalho, hoje, encontram-se nos grandes centros como Rio de Janeiro, São Paulo, Curitiba, Belo Horizonte, Porto Alegre, Fortaleza, Recife e segundo averiguações recentes, a tendência é de uma contínua expansão. \r\n\r\n', 'fa fa-css3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur commodo consequat finibus. Integer luctus, lacus vitae pretium venenatis, nisl ante fermentum lorem, non volutpat neque ex quis erat. Sed nec turpis et mauris condimentum vestibulum ut sed dui. Morbi eget orci quam.', 'fa fa-html5', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur commodo consequat finibus. Integer luctus, lacus vitae pretium venenatis, nisl ante fermentum lorem, non volutpat neque ex quis erat. Sed nec turpis et mauris condimentum vestibulum ut sed dui. Morbi ege', 'fa fa-gg-circle', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur commodo consequat finibus. Integer luctus, lacus vitae pretium venenatis, nisl ante fermentum lorem, non volutpat neque ex quis erat. Sed nec turpis et mauris condimentum vestibulum ut sed dui. Morbi eget orci quam. ');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_site.depoimentos`
--

CREATE TABLE `tb_site.depoimentos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `depoimento` text NOT NULL,
  `data` varchar(255) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_site.depoimentos`
--

INSERT INTO `tb_site.depoimentos` (`id`, `nome`, `depoimento`, `data`, `order_id`) VALUES
(1, 'Andre Cacueji Jeremias', 'Graças a Deus a escola esta a envoluir com a implementacao de internet', '22/06/2019', 1),
(2, 'Osvaldo Cafinji', 'por acaso gostei muito deste site', '23/06/2019', 2),
(3, 'Andre', 'Ola idealize', '15/07/2019', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_site.noticias`
--

CREATE TABLE `tb_site.noticias` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `conteudo` text NOT NULL,
  `capa` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_site.noticias`
--

INSERT INTO `tb_site.noticias` (`id`, `categoria_id`, `data`, `titulo`, `conteudo`, `capa`, `slug`, `order_id`) VALUES
(8, 3, '2019-06-22', 'Inscriçoes abertas na UJES Moxico', 'A Escola Superior Politécnico do Moxico, afecta a Universidade José Eduardo dos Santos (UJES), estão disponíveis 760 vagas, menos 70 em comparação com o período homólogo anterior. Segundo o director da única escola pública, Victor da Silva, mantém-se os cursos de Matemática, com 80 vagas, Física (80), Química (40), Geografia (120), Enfermagem (100), Análise Clínica (40), Contabilidade (220) e Ciências da Computação (80). Justificou a redução do número de vagas com insuficiência do número de docentes. Entre as dificuldades vividas, apontou a escassez de materiais de ensino nos laboratórios, como computadores, internet, recursos humanos, financeiros e o estado avançado de degradação da infra-estrutura física. Enquanto a directora pedagógico do Instituto Superior Politécnico Privado do Luena, Iraida Cabelleso, anunciou a existência de mil e 500 vagas contra 450 do ano inaugural (2017), para os dez cursos leccionados. Assegurou a manutenção do preço das propinas, sendo que os estudantes dos cursos de Ciências Jurídicas, Social e Humanas (Psicologia, Sociologia, Direito, Pedagogia, Economia, Relações Internacional, Gestão de empresas, Gestão de Recursos Humanos) vão continuar a pagar 20 mil Kwanzas, enquanto os do cursos de engenharia e saúde (Medicina Dentária e Arquitectura) vão pagar 24 mil kwanzas. Perspectivou, para o corrente ano, a implementação de um pólo universitário no município fronteiriço do Luau, embora tudo depende da procura dos cidadãos locais. Já o director do Instituto Superior Politécnico Privado Walinga do Moxico, Albano Freitas Sapalo, disse que a instituição tem capacidade para albergar cerca de seis mil novos estudantes, contra mil e 600 do ano anterior, o de estreia. Anunciou que no presente ano lectivo a instituição vai implementar quatro novos cursos, nomeadamente de Línguas Modernas, Contabilidade e Finanças, Farmácia e Informática de Gestão que vão se juntar aos oito cursos já existentes, nomeadamente Pedagogia, Sociologia, Psicologia, Direito, Gestão de Recursos, Economia, Enfermagem e Laboratório Clínico. O Walinga, segundo o seu director, está igualmente a estudar mecanismos para expandir o ensino superior em alguns municípios, com a criação de salas anexas. Em todo o país, o período das inscrições nas instituições de ensino superior vai de 3 a 22 do corrente mês e a realização dos exames para dia 2 de fevereiro, enquanto a abertura do ano académico está marcada para o dia 2 de Março.', '5d0df44db317e.jpg', 'inscricoes-abertas-na-ujes-moxico', 9),
(9, 3, '2019-06-22', 'Sobre o Curso de Computacao', 'O profissional técnico em informática pode executar variadas tarefas, como por exemplo:\r\n\r\n•	Suporte Técnico;\r\n•	Desenvolvimento de softwares;\r\n•	Webdesign – criação de sites;\r\n•	Configuração de Redes de computadores;\r\n•	Projetos em computação gráfica;\r\n•	Organização de banco de dados.\r\n\r\nPara seguir carreira de técnico de informática o interessado deve possuir, no mínimo, o Ensino Médio completo. Depois da formação básica como técnico em informática, é de grande conveniência a especialização em cursos de computação, informática e cursos de eletrônica. A maioria dos materiais utilizados na área é importada, então é imprescindível a noção de inglês para o entendimento destes manuais. \r\n\r\nCom a informação e as tecnologias em pleno desenvolvimento, são muitas as possibilidades de mercado para o profissional da área. As possibilidades de atuação dos técnicos de informática estão em instituições públicas, privadas e do terceiro setor que exigem sistemas de computadores, especialmente abrangendo programação de computadores. Em um mundo cada vez mais globalizado, a função deste profissional está nas estratégias para este nicho que se encontra em grande expansão, onde o mesmo deve descobrir aplicabilidades para as novas tecnologias da informação aos processos de negócios. Poder criar serviços e produtos novos para conquistar um diferencial em sua empresa, além de mostrar eficiência à administração, função esta, tradicional na área do emprego à informática. \r\n\r\nO profissional deve sempre estar se atualizando. Atuando de forma responsável e participativa no crescimento de atividades tecnológicas ligadas a área de informática. Ser criativo, se adaptar bem as mudanças e apresentar facilidade são requisitos muito importantes para quem deseja seguir a carreira.\r\n\r\nOs principais mercados de trabalho, hoje, encontram-se nos grandes centros como Rio de Janeiro, São Paulo, Curitiba, Belo Horizonte, Porto Alegre, Fortaleza, Recife e segundo averiguações recentes, a tendência é de uma contínua expansão. ', '5d0e29a8dcf24.jpg', 'sobre-o-curso-de-computacao', 8),
(10, 3, '2019-07-14', 'idealizati', '<p>inscri&ccedil;&otilde;es abertas na idealizati para mais informa&ccedil;&otilde;es contacte nos</p>', '5d2b25f1e2a68.jpg', 'idealizati', 10);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_site.servicos`
--

CREATE TABLE `tb_site.servicos` (
  `id` int(11) NOT NULL,
  `servico` text NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_site.servicos`
--

INSERT INTO `tb_site.servicos` (`id`, `servico`, `order_id`) VALUES
(4, 'Meu serviço #1', 4),
(5, 'Meu serviço #2 EDITADO novamente', 6),
(6, 'Meu serviço #3 EDITADO NOVAMENTE NOVAMENTE', 7),
(7, 'Meu servico #4', 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_site.slides`
--

CREATE TABLE `tb_site.slides` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `slide` varchar(255) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_site.slides`
--

INSERT INTO `tb_site.slides` (`id`, `nome`, `slide`, `order_id`) VALUES
(8, 'Inscrições abertas na idealizati', '5d2b259f180a9.jpg', 8),
(9, 'Meu slide', '594d4ec5ad5dd.jpg', 9);

-- --------------------------------------------------------

--
-- Estrutura da tabela `td_admin.chat`
--

CREATE TABLE `td_admin.chat` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `mensagem` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin.online`
--
ALTER TABLE `tb_admin.online`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_admin.usuarios`
--
ALTER TABLE `tb_admin.usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_admin.visitas`
--
ALTER TABLE `tb_admin.visitas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_site.categorias`
--
ALTER TABLE `tb_site.categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_site.depoimentos`
--
ALTER TABLE `tb_site.depoimentos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_site.noticias`
--
ALTER TABLE `tb_site.noticias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_site.servicos`
--
ALTER TABLE `tb_site.servicos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_site.slides`
--
ALTER TABLE `tb_site.slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `td_admin.chat`
--
ALTER TABLE `td_admin.chat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin.online`
--
ALTER TABLE `tb_admin.online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `tb_admin.usuarios`
--
ALTER TABLE `tb_admin.usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_admin.visitas`
--
ALTER TABLE `tb_admin.visitas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `tb_site.categorias`
--
ALTER TABLE `tb_site.categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tb_site.depoimentos`
--
ALTER TABLE `tb_site.depoimentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_site.noticias`
--
ALTER TABLE `tb_site.noticias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tb_site.servicos`
--
ALTER TABLE `tb_site.servicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tb_site.slides`
--
ALTER TABLE `tb_site.slides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `td_admin.chat`
--
ALTER TABLE `td_admin.chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
